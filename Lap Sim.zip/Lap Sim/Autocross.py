import numpy as np
from SolverFunctions import corner_speed_ceiling, lap_profile, energy_and_time
from Scoring import Scoring

def solve(tire, car, track, v_max=None):
    """Autocross: single lap from a standing start."""
    if v_max is None:
        v_max = corner_speed_ceiling(track, car, tire)
    v, v_fwd, v_bwd = lap_profile(track, car, tire, v_max, standing_start=True)
    t, P_pack, energy_J = energy_and_time(track, car, tire, v, v_max)
    lap_time = t[-1] + track.ds / max(v[-1], 0.1)
    ax_score = Scoring.getAutocrossScore(lap_time)
    return {"event": "autocross", "s": track.s, "v": v, "v_max": v_max,
            "v_fwd": v_fwd, "v_bwd": v_bwd, "t": t, "P_pack": P_pack,
            "lap_time": lap_time, "energy_kWh": energy_J / 3.6e6,
            "avg_power_kW": energy_J / lap_time / 1000,  "comp_point": ax_score}