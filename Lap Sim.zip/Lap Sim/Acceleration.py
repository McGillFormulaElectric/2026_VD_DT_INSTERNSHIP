from dataclasses import dataclass
import numpy as np
import Physics as ph
import Limits as lim
from Scoring import Scoring

@dataclass
class AccelSolver:
    track_length: float = 75.0     # m  length of acceleration event
    run_up:       float = 0.3      # m  distance before start line where car starts moving
    v0:           float = 0.0      # m/s  initial speed

    def simulate(self, tire, car):
        
        def step_size(k):
            if k < 1000: return 1e-4
            if k < 2000: return 1e-3
            return 1e-2

        # Initialize variables
        v = self.v0
        s = -self.run_up # Start before the start line
        Ax_prev = 0.0
        k = 0

        # Lists to store results for plotting or analysis
        log = {key: [] for key in (
            "dist", "ds", "dt", "v", "Ax",
            "FzF", "FzR", "Downforce", "Drag", "Frolling", "Fx_penalties",
            "Fx_tractive", "Fx_net",
            "P_F", "P_R", "EfficiencyF", "EfficiencyR", "PackPower",
            "rpm", "TmotorF", "TmotorR",
        )}

        # Simulation loop
        while s < self.track_length and k <= 200_000:
            ds = step_size(k)

            # Aero
            Downforce = ph.downforce(car, v)
            Drag = ph.drag(car, v)

            # Calculate normal force (N)
            FzF = max(ph.FL_Fz(car, Downforce, 0.0, Ax_prev), 0.0)
            FzR = max(ph.RL_Fz(car, Downforce, 0.0, Ax_prev), 0.0)

            # Calculate penalties (N)
            Frolling = ph.rolling_resistance(car, v, 2.0*FzF + 2.0*FzR)
            Fx_penalties = Drag + Frolling

            # Calculate propulsive force (N)
            t = lim.tractive_force_4wd(tire, car, FzF, FzF, FzR, FzR, max(v, 0.1))
            v = t["v"]
            Fx_net = t["Fx_total"] - Fx_penalties
            
            # Calculate acceleration (m/s²)
            Ax = Fx_net / car.mass_effective

            # Update speed and position
            v_next = np.sqrt(max(v**2 + 2.0*Ax*ds, 0.0))
            v_bar = 0.5*(v + v_next)
            if v_bar > 1e-6:
                dt = ds / v_bar
            elif Ax > 0:
                dt = np.sqrt(2.0*ds/Ax)
            else:
                break   # car stationary and cannot accelerate, stop the run

            # Store results
            for key, val in (
                ("dist", s), ("ds", ds), ("dt", dt), ("v", v), ("Ax", Ax),
                ("FzF", FzF), ("FzR", FzR),
                ("Downforce", Downforce), ("Drag", Drag), ("Frolling", Frolling),
                ("Fx_penalties", Fx_penalties),
                ("Fx_tractive", t["Fx_total"]), ("Fx_net", Fx_net),
                ("P_F", t["P_F"]), ("P_R", t["P_R"]),
                ("EfficiencyF", t["EfficiencyF"]), ("EfficiencyR", t["EfficiencyR"]),
                ("PackPower", t["PackPower"]), ("rpm", t["rpm"]),
                ("TmotorF", t["TmotorF"]), ("TmotorR", t["TmotorR"]),
            ):
                log[key].append(val)

            Ax_prev = Ax
            v = v_next
            s += ds
            k += 1

        out = {key: np.asarray(val, dtype=float) for key, val in log.items()}
        out["time"] = np.concatenate(([0.0], np.cumsum(out["dt"])[:-1]))
        out["EnergyPack"] = float(np.sum(out["PackPower"] * out["dt"]))
        out["time_total"] = float(np.sum(out["dt"]))
        out["v_final"] = float(v)

        lap_time = out["time_total"]
        return {"event": "acceleration", "s": out["dist"], "v": out["v"],
                "v_max": out["v_final"],
                "t": out["time"], "P_pack": out["PackPower"],
                "lap_time": lap_time, "energy_kWh": out["EnergyPack"] / 3.6e6,
                "avg_power_kW": out["EnergyPack"] / lap_time / 1000,
                "comp_point": Scoring.getAccelScore(lap_time),
                "peak_Ax": float(np.max(out["Ax"])),
                "rev_limited": bool(out["rpm"].max() >= car.rpm_cap - 1)}